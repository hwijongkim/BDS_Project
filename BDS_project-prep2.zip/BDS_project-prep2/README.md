# BDS_project
3팀 프로젝트를 위한 repo 입니다.

## Desktop에 repo 다운받는 방법.
1. 오른쪽 위에 초록색 Clone or download를 누른다.
2. Download Zip을 눌러서 한방에 받는다.

## 코드 업데이트
1. Git 계정을 만들고
2. 오른쪽 위에 Fork를 눌러서 개인 계정에서 수정할 수 있도록 한다.
3. 메인에 합치고 싶은 코드가 New pull request를 통해서 한다.

## 자세한 사용법
[git help page](https://help.github.com/)
